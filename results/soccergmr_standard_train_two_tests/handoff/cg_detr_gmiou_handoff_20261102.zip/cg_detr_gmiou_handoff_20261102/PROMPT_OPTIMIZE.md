# 清空上下文后使用：CG-DETR G-mIoU优化

请读取并执行本交接说明。工作区为`/home/guoxiangyu`，Python固定为`/home/guoxiangyu/miniconda3/envs/gmr/bin/python`。只由当前会话实施，不启动其他代理。

先依次读取：

1. `/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102/README.md`
2. 同目录`MANIFEST.json`、`CHECKPOINTS_CG_DETR.json`。
3. 同目录`TRAINING_HANDOFF.md`、`TESTING_HANDOFF.md`、`OPTIMIZATION_NOTES.md`。
4. 运行同目录`verify_handoff.py`；必要时加`--features`核验全部已登记特征。此脚本只读，不训练、不推理。

目标是在当前SoccerGMR的CG-DETR路线中做特定改动，提高G-mIoU，同时完整报告定位性能。若本轮用户明确指定方法或改动，以该指令为准。否则默认重点定位`GMR + Multi + GEQ Full`，保留GMR、Multi及Multi+GEQ Frozen作为对照；先在Standard Val完成诊断，依据诊断确定一个可验证改动，不自动启动整套原始训练或24项Test。阅读交接包本身不构成启动训练的指令。

必须准确找到目标模型：

- 主目标`multi_geq_full`：`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/geq_protocol_experiments/20261031/cg_detr/multi/full/best.ckpt`。
- SHA256：`535f94493897cb825c2b4c2b502fa1abf2bdaf223df635770ba0abb23157f1f1`。
- 它由原Multi best继续训练GEQ Full得到；父Multi SHA256为`c229ccf56f81131e2d3fa9dafdf3595ef7753b6975c28dbf70c23466605d2a98`。
- 构造`Adapter('cg_detr','multi')`和`RouteGEQ(adapter.base,'cg_detr','full')`后，严格加载主目标检查点的**完整**`model`。只加载父Multi会丢失既有GEQ及已更新的原生权重。代码和模型布局见交接包。
- 原模型mAP与GEQ选模规则不同：GMR/Multi按Standard Val正例mAP；GEQ按Standard Val的G-mIoU@1在0.4/0.5/0.6三点均值。不要混入旧`cg_detr/gmr`、seed2026单独部署、历史main E1、固定四轮GEQ、Shared、Charades或其他骨干。

先完成以下恢复与诊断，再实施用户授权的改动：

1. 核对六个模型身份、父子关系、严格加载记录及代码快照。记录将使用哪个初始化，是继续已有GEQ Full，还是从父Multi重新训练一个新GEQ；二者须分别命名。
2. 新建独立工作目录，例如`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_optimization_runs/`下新的实验子目录。修改隔离副本，保留所有旧模型、代码、标签、特征、预测、报告。记录修改前后代码哈希和完整超参数。原训练入口有硬编码输出，不能原地直接训练。
3. 使用Standard Train/Val，确认4138/465条、自然正负样本、视频SlowFast→CLIP→TEF顺序和原生时间/文本处理。先导出或复用身份匹配的Val预测，计算三点G-mIoU@1/@3、AUROC、N-acc、Rej-F1、正例定位指标及oracle存在性上限；把负例误接收造成的损失与正例误拒绝造成的损失分开。不得用Full Test来确定改动或选参数。
4. 默认主要选模目标仍是Val三点G-mIoU@1均值；同时监控@3、mAP和定位退化。若用户要求改选模指标，应先明确写入新协议。改善存在性分数的改动先做定位完全冻结的对照，再判断是否需要联合训练。校准参数只能在Train/Val拟合。
5. 若有新训练，先在真实全负、单GT、多GT小批上验证有限loss/梯度、正确冻结、完整严格保存重载、无训练辅助路线泄漏到eval。原生Multi辅助分类损失对负例也可能非零，不能将整个Multi训练误写成只对正例计算。
6. GPU执行前查看全部已有CUDA作业；每卡最多2项、全机最多4项，不终止其他任务。为新实验加锁。不要调用旧队列或会自动刷旧图的入口。
7. 配置及Val-best冻结后再执行独立Test评估。Full-Decodable采用2970条独立Full qid及Full特征，不能复用Standard预测。Frozen只替换父模型同一测试划分的存在性分数，候选和全部定位指标必须一致。完整规则见TESTING_HANDOFF.md。
8. G-mIoU始终用0–1，mAP等用百分数，所有增减统一相对同骨干GMR；负例全拒绝的G-mIoU约0.4502是指标性质，不能把它当成定位能力提升。

已有Test事实只用于理解问题，不用于新试验选模：CG-DETR的Multi+GEQ Full在Full-Decodable上的mAP=15.93，GMR为13.58；但三点G-mIoU@1分别为0.3593/0.4455/0.4929，低于GMR的0.5068/0.5143/0.5150。它自己的oracle存在性上限为@1=0.5743、@3=0.5123。这提示存在性决策值得优先诊断，**尚未证明校准或某种新loss一定有效**。完整六方法结果见CG_FULL_RESULTS.csv。

Full Test及其曲线已被查看并用于提出研究问题，所以后续在该测试集上的改进应标记为探索性结果；不要重新声称它是从未看过的独立Test。Standard Test与Full Test有1036个视频-查询对重叠。正式无偏泛化结论需要额外独立、预先锁定的评估集或新的评估协议。默认不引入Full Train/Val训练；如改用它们，必须另立数据/训练版本。

交付应包含：初始化模型与哈希、改动代码、Val诊断和选模证据、有限的实验记录、完整配置/日志/预测/官方指标/覆盖和哈希、对旧结果的比较，以及清晰的“已完成/未启动/待执行”状态。不能把准备命令或小批成功当成完整训练、完整Test或性能提升。
