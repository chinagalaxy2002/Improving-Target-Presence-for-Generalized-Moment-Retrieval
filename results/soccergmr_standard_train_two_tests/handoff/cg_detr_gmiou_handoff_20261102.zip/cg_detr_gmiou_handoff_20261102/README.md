# CG-DETR复现、测试与G-mIoU优化交接

本包为清空会话后的持久入口，只整理真实已存在的六方法身份、训练/测试来源及优化注意事项；**本次没有训练、微调或重新推理模型**。代码和小型记录有快照，大型检查点/特征/预测按绝对路径及SHA256引用。

开始新会话时可直接复制：

```text
请读取并执行：
/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102/PROMPT_OPTIMIZE.md
本轮仅关注CG-DETR。先核验模型身份、恢复训练/测试上下文并完成Standard Val诊断，再围绕我指定的改动优化G-mIoU。保留旧模型及正式结果。
```

如只复查既有结果或测试模型，改读[PROMPT_EVAL_ONLY.md](PROMPT_EVAL_ONLY.md)。训练来源及隔离复现命令见[TRAINING_HANDOFF.md](TRAINING_HANDOFF.md)，完整测试规则见[TESTING_HANDOFF.md](TESTING_HANDOFF.md)，下一步诊断见[OPTIMIZATION_NOTES.md](OPTIMIZATION_NOTES.md)。

## 最关键的模型身份

默认优化对象为**GMR+Multi+GEQ Full**：

```text
/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/geq_protocol_experiments/20261031/cg_detr/multi/full/best.ckpt
SHA256: 535f94493897cb825c2b4c2b502fa1abf2bdaf223df635770ba0abb23157f1f1
父Multi: /home/guoxiangyu/Improving-Target-Presence-for-Generalized-Moment-Retrieval/backbonefolder/multiroute_gmr/runs/cg_detr/multi/best.ckpt
父SHA256: c229ccf56f81131e2d3fa9dafdf3595ef7753b6975c28dbf70c23466605d2a98
```

六模型完整路径、hash、选模、原生布局和Test结果：[CHECKPOINTS_CG_DETR.json](CHECKPOINTS_CG_DETR.json)。机器入口：[MANIFEST.json](MANIFEST.json)。主目标的GEQ best为Val选出的第1轮，训练实际跑到第7轮；不要混入历史main E1。

## 当前问题的实测起点

在Full-Decodable Test(2970/2986)上，Multi+GEQ Full的mAP=15.93%，相对GMR 13.58%增加2.35个百分点；G-mIoU@1在τ=.4/.5/.6为.3593/.4455/.4929，均低于GMR的.5068/.5143/.5150。其自身oracle存在性上限为@1=.5743、@3=.5123。这支持先在Val拆解存在性误判及定位质量的损失，不能直接证明某种校准或新loss一定有效。

[六方法Full结果CSV](CG_FULL_RESULTS.csv) · [当前CG曲线（含mAP和oracle横线）](snapshot/curves/cg_detr.pdf)

![当前CG曲线](snapshot/curves/cg_detr.png)

GMR有效batch8、Multi有效batch32；GEQ则batch32。Standard Train/Val=4138/465；旧Standard Test=1036；Full-Decodable Test=2970（原始2986中16条未覆盖）。所有模型只用Standard Train/Val得到best，Full数据集和GEQ Full模式不同。

## 目录及使用

| 文件/目录 | 内容 |
|---|---|
| PROMPT_OPTIMIZE.md | 新会话恢复与特定优化提示词 |
| PROMPT_EVAL_ONLY.md | 新会话只核验/复查/测试提示词 |
| TRAINING_HANDOFF.md | 原始训练链、超参数、选模、续训与重启差别、隔离命令 |
| TESTING_HANDOFF.md | 独立Full入口、数据身份、Frozen规则、指标和覆盖 |
| OPTIMIZATION_NOTES.md | 已测事实、Val损失分解、可检验的优化假设 |
| MANIFEST.json | 六检查点、live文件/快照hash、GT、特征来源和训练配置 |
| checkpoint_layouts/ | 六个实际checkpoint的键/形状/dtype元数据 |
| snapshot/ | 已核验源码、训练日志/配置、Full严格加载与指标证据 |
| FEATURE_SHA256.json | Standard训练/验证/测试及Full测试唯一特征的SHA256 |
| ENVIRONMENT.json | Python、Torch及已安装包版本 |
| verify_handoff.py | 只读核验，默认不启动CUDA/训练/推理 |
| prepare_native_runtime.py | 仅准备新隔离原生训练目录，不执行训练 |

核验：

```bash
/home/guoxiangyu/miniconda3/envs/gmr/bin/python -B /home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102/verify_handoff.py
```

完整检查已登记特征时加`--features`。live源码若被未来实验修改，核验会明确失败；应使用快照还原旧实现或建立新的实验清单，不可静默接受漂移。不要为了让旧验证通过而改写旧完成标记。

## 后续实验的口径

用户指定的具体改动优先。默认在Standard Train/Val上实施与选模；Test结果/曲线已经看过，用于形成研究问题，后续该Test上的提升应标明探索性，不能再次称为完全未触及的独立Test。两个Test共享1036个视频-查询对；Full长序列/时长偏差亦需保留说明。新数据或新时间处理必须另立协议、统一重评对照。

只编辑新副本，旧检查点/特征/预测/报告保留。GPU同时最多每卡2项、全机4项，计入其他作业。不要因为读取本交接包而自动启动旧训练入口、旧队列或24项测试。
