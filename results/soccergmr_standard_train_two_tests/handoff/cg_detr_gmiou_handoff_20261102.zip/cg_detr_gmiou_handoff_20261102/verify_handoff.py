#!/usr/bin/env python3
"""Read-only verification. No model construction, CUDA, training or inference."""
import argparse
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()

def verify(check_features=False):
    manifest=json.loads((HERE/'MANIFEST.json').read_text())
    assert sha(HERE/manifest['feature_hash_file'])==manifest['feature_hash_file_sha256']
    package_index=HERE/'PACKAGE_FILES_SHA256.json'
    if package_index.is_file():
        for name,h in json.loads(package_index.read_text()).items():
            assert sha(HERE/name)==h,f'Handoff package changed: {name}'
    n=0
    for group in ('checkpoints','live_files','snapshots'):
        entries=manifest[group]
        if group=='checkpoints': entries={e['checkpoint']:e['sha256'] for e in entries}
        for name,h in entries.items():
            path=HERE/name if group=='snapshots' else Path(name)
            assert path.is_file(),str(path)
            assert sha(path)==h,f'Hash changed: {path}; use documented snapshot, do not silently select another best'
            n+=1
    for entry in manifest['checkpoints']:
        d=Path(entry['full_test_directory'])
        complete=json.loads((d/'COMPLETE.json').read_text())
        assert complete['strict_load'] and complete['coverage']['rows']==2970
        assert complete['identity']['checkpoint_sha256']==entry['sha256']
        assert complete['predictions_sha256']==sha(d/'predictions.jsonl')
        assert complete['metrics_sha256']==sha(d/'metrics.json')
        if entry['method'].endswith('_frozen'):
            assert complete['frozen']['native_tensors_equal']
            assert complete['frozen']['full_candidates_exact'] and complete['frozen']['all_localization_metrics_exact']
    if check_features:
        for name,h in json.loads((HERE/'FEATURE_SHA256.json').read_text()).items():
            assert sha(name)==h,f'Feature changed: {name}'
            n+=1
    print(json.dumps(dict(passed=True,checkpoints=6,formal_test_rows_each=2970,checked_files=n,
                          feature_hashes_checked=check_features,training_started=False,inference_started=False),ensure_ascii=False))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--features',action='store_true')
    args=parser.parse_args();verify(args.features)
