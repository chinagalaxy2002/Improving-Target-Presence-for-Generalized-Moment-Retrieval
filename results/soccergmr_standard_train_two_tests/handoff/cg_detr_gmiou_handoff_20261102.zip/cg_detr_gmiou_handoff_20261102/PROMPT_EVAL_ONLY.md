# 清空上下文后使用：只定位/复查CG-DETR既有测试

请先读取`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102/README.md`、`CHECKPOINTS_CG_DETR.json`和`TESTING_HANDOFF.md`，并运行同目录`verify_handoff.py`。只由当前会话实施，不启动其他代理。

范围仅CG-DETR当前六方法：GMR、GMR+GEQ Frozen、GMR+GEQ Full、Multi、Multi+GEQ Frozen、Multi+GEQ Full。使用清单的绝对路径及SHA256，不搜索同名旧best。严格区分Standard Test(1036)与Full-Decodable Test(2970/2986)，以及Full数据集与GEQ Full模式。

这是eval-only任务，不重新训练、不微调、不重选模型、不按Test调参。当前六项Full结果已合法完成，输入身份/模型/代码/预测哈希一致时优先复用。旧Full入口index为18–23；不要启动其他骨干或整个24项队列。若用户要求对新的检查点测试，创建独立CG-only入口及输出清单，不改旧清单和输出根。

检查完整state_dict严格加载记录，独立Full qid文本特征、2970条完整GT、负例空窗口、多GT、duration、mask、流顺序和原生后处理。Frozen复制对应父模型同一Full输入的候选，仅替换存在性分数，候选及全部定位指标必须完全一致。GEQ Full加载完整已更新原生权重。

报告全部正式指标，G-mIoU@1/@3在0.4/0.5/0.6三点，单位0–1；其余百分数；增减相对同骨干GMR。原始Full 2986中的16条历史排除、75步截断及3段时长偏差单列。不得将小批成功、准备队列或合法复用说成新完成了模型推理。

如用户只问数值或要重绘图，直接读取已核验预测/指标，离线完成；oracle横线是完美存在性且候选固定时六方法最高可恢复G-mIoU（CG @1=.5743、@3=.5123），不是可部署成绩或Test选出的阈值。
