# CG-DETR训练来源与复现

本文件说明已有模型如何得到，并给出未来隔离复现的方法。本次交接包生成没有运行训练。重用现有best可以严格复现已有权重；从头重训使用同一配置仍不承诺得到相同文件哈希或逐位相同的结果。

## 六个模型及主目标

完整绝对路径、SHA256、epoch、父检查点、训练终止轮数、布局和Test结果见[CHECKPOINTS_CG_DETR.json](CHECKPOINTS_CG_DETR.json)。`checkpoint_layouts/`保存每个state_dict键的形状和dtype。

```text
Standard Train/Val
 ├─ CG原生GMR + MultiRouteModel(variant='baseline') → GMR best
 │    ├─ RouteGEQ(mode='frozen') → GMR + GEQ Frozen
 │    └─ RouteGEQ(mode='full')   → GMR + GEQ Full
 └─ CG原生GMR + MultiRouteModel(variant='multi')    → Multi best
      ├─ RouteGEQ(mode='frozen') → Multi + GEQ Frozen
      └─ RouteGEQ(mode='full')   → Multi + GEQ Full【默认优化对象】
```

| 方法 | best保存的epoch | 人类轮次 | 本次既有训练最终轮次 |
|---|---:|---:|---:|
| GMR | 74（从0计数） | 75 | 95 |
| GMR+GEQ Frozen | 4（从1计数） | 4 | 10 |
| GMR+GEQ Full | 1（从1计数） | 1 | 7 |
| Multi | 119（从0计数） | 120 | 140 |
| Multi+GEQ Frozen | 1（从1计数） | 1 | 7 |
| Multi+GEQ Full | 1（从1计数） | 1 | 7 |

GEQ best刚好为第1轮不能解释为“历史main E1”或固定1轮训练。它是最多20轮、Val选模和早停后的第1轮best。

## 原生GMR与Multi

训练控制器：`/home/guoxiangyu/Improving-Target-Presence-for-Generalized-Moment-Retrieval/backbonefolder/multiroute_gmr/run.py`。

构造链：`Experiment('cg_detr', variant).build()` → 动态加载`backbonefolder/cg_detr/train_gmr.py`的config/build_model → `gmr_source/cg_detr/model.py` → 外包`multiroute_gmr/multiroute.py:MultiRouteModel`。当前GMR存在性头池化最后一层decoder的10个proposal槽，使用amax后MLP输出单logit。主criterion为`GMRCriterion`，存在性BCE覆盖正负样本，原生主定位损失使用正例。

Multi在训练时添加Separate-FFN及Instruction两条路线，24个辅助query，每个GT复制2次，辅助loss权重总系数0.3，4个instruction token；推理只保留原主路线10候选。**辅助路线的`_loss()`分类交叉熵仍覆盖负例batch项**，空GT只令span/GIoU项为零。修改时应读实现，不能把整个Multi loss简化为“所有定位相关损失均只对正例”。

| 配置 | GMR | Multi |
|---|---:|---:|
| seed | 2023 | 2023 |
| 初始化 | 当前原生CG及包装器随机初始化，不加载旧seed2026 best | 同左 |
| microbatch | 2 | 32 |
| 梯度累积 | 4 | 1 |
| 有效batch | 8 | 32 |
| AdamW lr / wd | 5e-5 / 1e-4 | 5e-5 / 1e-4 |
| scheduler | StepLR，step_size=400，gamma=0.1 | 同左 |
| 最大轮数 | 400 | 400 |
| 验证间隔 | 每5轮 | 每5轮 |
| 选模 | Standard Val正例未门控mAP最大 | 同左 |
| 早停 | 当前轮−best轮≥20 | 同左 |
| grad clip / AMP | 0.1 / 关闭 | 同左 |
| workers | 2，persistent_workers | 同左 |

原始配置/历史/选模证据在`snapshot/training_records/{gmr,multi}/`。GMR Val best mAP=18.79，Multi=20.64。两者训练batch不同，比较不能宣称训练预算一致。

`backbonefolder/cg_detr/train_gmr.py`还包含一个旧的独立seed2026训练main，但当前模型由外层multiroute控制器覆盖训练配置并构造。**不要运行该文件main或加载`backbonefolder/cg_detr/gmr/best.ckpt`来替代本清单模型。**

## Standard输入

标签真实来源：`/home/guoxiangyu/VLMbasedIter_momentretrival/generalized-moment-retrieval/data/label/Standard/{train,val,test}.jsonl`。

| split | 总数 | 正例 | 负例 |
|---|---:|---:|---:|
| Train | 4138 | 2136 | 2002 |
| Val | 465 | 255 | 210 |
| Test | 1036 | 544 | 492 |

视频和文本特征真实根目录：`/home/guoxiangyu/VLMbasedIter_momentretrival/generalized-moment-retrieval/Soccergmr/`，不是`Full_features/`。读取`slowfast/<Standard_vid>.npz:features`2304维和`clip/...:features`512维，各流分别L2归一化（分母+1e-5），按SlowFast→CLIP拼接，再加2维TEF，总2818维。文本读取`clip_text/qid<Standard_qid>.npz:last_hidden_state`，取前32 token、512维并按原生规则归一化。不要自行移除CLIP padding token或换mask规则。

主配置：hidden=256，3层encoder、3层decoder、8 heads、FFN=1024、dropout=0.1、10主query、视频最大75步、clip_length=2秒、10个global prompt、45个dummy token。训练span由`relevant_windows/duration`转换为cxw；不得从`moment`重复扩窗。`vid=None`关闭合成视频/查询负配对。CG的targets只用于相应训练路径，不可传入推理。

## GEQ Frozen与GEQ Full

代码：`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/gmr_geq_protocol_kit/`，主要读`run_study.py`、`native_adapter.py`、`geq_model.py`、`validation_selection.py`和`study_paths.py`。快照在`snapshot/gmr_geq_protocol_kit/`。

GEQ从对应**已训练好的原生GMR/Multi best**开始。一个256维global event query先读投影文本，再逐层读3层encoder的视频证据，最后线性头输出存在性logit。CG证据捕获有offset=1及video_length截片；调整dummy/global token布局时必须核对该对齐，不能盲目修改。

Frozen把原生base设eval、requires_grad=False并detach，只优化GEQ BCE。Full同时更新base与GEQ，loss=`原生GMR/Multi loss + GEQ BCE`，保留原生辅助路线训练行为。它不会仅更新一个存在性MLP。

GEQ通用配置：seed2023，batch32，无梯度累积，AdamW；lr_geq=3e-5，Full的lr_base=1e-5，wd=1e-4，clip=0.1，AMP关闭，workers2，最多20轮。每轮验证，按Val G-mIoU@1在τ=0.4/0.5/0.6三点均值选best；连续**超过5轮**无均值改善才停止。均值相同时，只有“三点均高于参考baseline”状态变好才可按源码tie规则换best，且不因此清零stale计数。具体以`ValidationSelector`为准。

读取配置时`actual_video_feature_order=null`不表示没有视频特征；CG数据集在模块内硬编码顺序。Full评测入口记录的真实顺序是SlowFast→CLIP。

## 隔离复现原生训练的命令

以下是未来执行说明，本次没有运行训练。先检查所有CUDA作业，选择空闲GPU；每卡最多2项、全机最多4项。`prepare_native_runtime.py`只复制小型代码快照到**不存在的新目录**，不复制模型权重、不训练。

```bash
CG_HANDOFF=/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102
CG_PY=/home/guoxiangyu/miniconda3/envs/gmr/bin/python
CG_RUN_ROOT=/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_optimization_runs/native_reproduction_seed2023
"$CG_PY" -B "$CG_HANDOFF/verify_handoff.py"
"$CG_PY" -B "$CG_HANDOFF/prepare_native_runtime.py" --output "$CG_RUN_ROOT"
export GMR_FIGURE_REFRESH="$CG_RUN_ROOT/legacy_refresh_disabled.sh"
export CUDA_VISIBLE_DEVICES=0
"$CG_PY" -B "$CG_RUN_ROOT/backbonefolder/multiroute_gmr/run.py" --backbone cg_detr --variant baseline --mode smoke
"$CG_PY" -B "$CG_RUN_ROOT/backbonefolder/multiroute_gmr/run.py" --backbone cg_detr --variant baseline --mode train
"$CG_PY" -B "$CG_RUN_ROOT/backbonefolder/multiroute_gmr/run.py" --backbone cg_detr --variant multi --mode smoke
"$CG_PY" -B "$CG_RUN_ROOT/backbonefolder/multiroute_gmr/run.py" --backbone cg_detr --variant multi --mode train
```

命令串行执行；不要附加`--test-after-training`用于探索。新runtime去除旧队列restart/reuse动作和GPU强制分配，保留历史两种batch配置，输出仅在新runtime的`runs/cg_detr/`。保存初始化、所有配置和代码哈希。快照是当下可读源码，已核对GEQ记录中的代码哈希；详见MANIFEST。

## 从原有父best独立复现GEQ

下面是完整旧协议的复现示例，不是探索阶段通用trial入口。`run_study.py`在Val选模结束后会**自动执行Standard Test**，并可能读取父模型既有Standard预测。所有试探性优化必须先复制/改造为Train/Val-only入口，隔离自动Test块。

```bash
CG_PY=/home/guoxiangyu/miniconda3/envs/gmr/bin/python
CG_NEW_GEQ=/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_optimization_runs/geq_reproduction_seed2023
CUDA_VISIBLE_DEVICES=0 GMR_PROTOCOL_OUTPUT="$CG_NEW_GEQ" "$CG_PY" -B /home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/gmr_geq_protocol_kit/run_study.py --backbone cg_detr --variant multi --mode full
```

`--variant baseline/multi`与`--mode frozen/full`组成四个GEQ配置。必须指定新的`GMR_PROTOCOL_OUTPUT`，否则会指向历史目录。该示例使用清单中的原有父best；若要用“刚重训的新父模型”，需改`GMR_RUNTIME_ROOT`指向新runtime的`multiroute_gmr`，严格核对`source_dir()`和对应父预测的归属，并记录这是不同初始化版本。

## 继续当前GEQ Full，而非从父模型重启

在独立脚本中构造完整包装再加载：

```python
adapter = Adapter('cg_detr', 'multi')
model = RouteGEQ(adapter.base, 'cg_detr', 'full').cuda()
state = torch.load(target_checkpoint, map_location='cpu', weights_only=False)
model.load_state_dict(state['model'], strict=True)
```

target_checkpoint必须来自清单的`multi_geq_full`，并预先校验SHA256。`run_study.construct()`默认只加载父Multi，再随机初始化GEQ；它本身不是“续训已有GEQ Full”。已有GEQ `best.ckpt`不包含optimizer，继续优化需创建新optimizer并记录新阶段；`last.ckpt`带optimizer但属于最后轮次，不可拿它冒充既有Val-best。

若要新增模型参数，旧完整模型必须先严格加载；新参数初始化、模型迁移和新增键须显式列出，不能用`strict=False`掩盖遗漏。源模型训练预算与GEQ微调预算均在metadata中保留。
