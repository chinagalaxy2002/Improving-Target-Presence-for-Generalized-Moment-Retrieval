#!/usr/bin/env python3
"""Stage an isolated native CG training runtime; never execute training."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

HERE=Path(__file__).resolve().parent

def prepare(output):
    output=Path(output).expanduser().resolve()
    if output.exists():raise FileExistsError(f'Refusing an existing output directory: {output}')
    manifest=json.loads((HERE/'MANIFEST.json').read_text())
    source=HERE/'snapshot/backbonefolder'
    for name,h in manifest['snapshots'].items():
        if name.startswith('snapshot/backbonefolder/'):
            assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==h,name
    output.mkdir(parents=True,exist_ok=False)
    shutil.copytree(source,output/'backbonefolder')
    # Queue actions from the historical machine must not migrate or reuse any
    # job. Preserve the measured batch settings in the new empty runtime.
    profile=dict(revision='cg_handoff_isolated_runtime',jobs={
        'cg_detr/baseline':dict(microbatch=2,gradient_accumulation=4),
        'cg_detr/multi':dict(microbatch=32,gradient_accumulation=1)})
    (output/'backbonefolder/multiroute_gmr/execution_plan.json').write_text(json.dumps(profile,indent=2)+'\n')
    payload=dict(prepared_only=True,training_started=False,source_snapshot=str(source),
                 original_source_files_modified=False,output=str(output),
                 required_python=manifest['python'],
                 native_output_root=str(output/'backbonefolder/multiroute_gmr/runs'),
                 note='Use --mode smoke then --mode train in separate processes. No automatic Test. This copies code, not historical weights or datasets.')
    (output/'PREPARED.json').write_text(json.dumps(payload,indent=2)+'\n')
    print(json.dumps(payload,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True)
    prepare(p.parse_args().output)
