#!/usr/bin/env python3
"""Freeze CG identities, metadata and code; never run a model or a trainer."""
import csv
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import torch

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent
CORE=Path('/home/guoxiangyu/Improving-Target-Presence-for-Generalized-Moment-Retrieval/backbonefolder/multiroute_gmr')
KIT=PROJECT/'gmr_geq_protocol_kit'
FULL=PROJECT/'soccergmr_full_test_20261102'
DATA_ROOT=Path('/home/guoxiangyu/VLMbasedIter_momentretrival/generalized-moment-retrieval')
OFFICIAL=Path('/home/guoxiangyu/GMR_Unseen/experiments/table2_repro_20261022/shared/official_eval')
METHODS=['gmr','gmr_geq_frozen','gmr_geq_full','multi','multi_geq_frozen','multi_geq_full']

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(2**20),b''):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(Path(path).read_text())
def rows(path):return [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]
def dump(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str,allow_nan=False)+'\n')

def main():
    live={};snapshots={}
    def copy(path,relative):
        path=Path(path);out=HERE/relative;out.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,out);h=sha(path);assert sha(out)==h
        live[str(path)]=h;snapshots[str(relative)]=h
    for directory,prefix in [(KIT,'snapshot/gmr_geq_protocol_kit'),
                             (CORE.parent/'cg_detr/gmr_source','snapshot/backbonefolder/cg_detr/gmr_source'),
                             (OFFICIAL,'snapshot/official_eval')]:
        for p in directory.rglob('*'):
            if p.is_file() and p.suffix in ('.py','.json','.yaml','.yml','.txt') and '__pycache__' not in p.parts:
                copy(p,Path(prefix)/p.relative_to(directory))
    for name in ('run.py','multiroute.py','execution_plan.py','execution_plan.json'):
        copy(CORE/name,Path('snapshot/backbonefolder/multiroute_gmr')/name)
    copy(CORE.parent/'cg_detr/train_gmr.py',Path('snapshot/backbonefolder/cg_detr/train_gmr.py'))
    for name in ('eval_only.py','common.py','audit_inputs.py','run_all.py','build_report.py','INPUT_AUDIT.json','AUDIT.json','COMPLETE.json','RESULTS.json','RESULTS.csv','README.md'):
        copy(FULL/name,Path('snapshot/full_eval')/name)
    for name in ('plot_curves.py','PROVENANCE.json','ORACLE_PRESENCE_BY_METHOD.csv','ORACLE_CEILINGS.csv','cg_detr.pdf','cg_detr.png'):
        copy(FULL/'gmiou_threshold_curves'/name,Path('snapshot/curves')/name)
    copy(PROJECT/'soccergmr_full_test_handoff_20261102/DATA_AUDIT.json',Path('snapshot/DATA_AUDIT.json'))
    all_entries=read(PROJECT/'soccergmr_full_test_handoff_20261102/CHECKPOINTS.json')['checkpoints']
    entries=[];full_results={r['method']:r for r in read(FULL/'RESULTS.json') if r['backbone']=='cg_detr'}
    oracle={r['method']:r for r in csv.DictReader((FULL/'gmiou_threshold_curves/ORACLE_PRESENCE_BY_METHOD.csv').open()) if r['backbone']=='cg_detr'}
    for i,e in enumerate(all_entries):
        if e['backbone']!='cg_detr':continue
        assert sha(e['checkpoint'])==e['sha256']
        state=torch.load(e['checkpoint'],map_location='cpu',weights_only=False)
        assert state['epoch']==e['epoch_raw'] and len(state['model'])==e['state_keys']
        method=e['method'];directory=Path(e['checkpoint']).parent
        metadata=dict(epoch_raw=state['epoch'],state_keys=len(state['model']),checkpoint_keys=list(state),
                      tensors={k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in state['model'].items()})
        dump(HERE/'checkpoint_layouts'/f'{method}.json',metadata)
        for name in ('CONFIG.json','COMPLETE.json','PREFLIGHT.json','experiment_config.json','execution_plan.json',
                     'frozen_checkpoint.json','history.jsonl','best_val_metrics.json','baseline_val_metrics.json',
                     'best_val_predictions.jsonl','val_predictions.jsonl','baseline_val_predictions.jsonl',
                     'test_metrics.json','status.json'):
            if (directory/name).is_file():copy(directory/name,Path('snapshot/training_records')/method/name)
        test_dir=FULL/'runs/cg_detr'/method
        for name in ('COMPLETE.json','PREFLIGHT.json','metrics.json'):
            copy(test_dir/name,Path('snapshot/full_test_records')/method/name)
        live[str(test_dir/'predictions.jsonl')]=sha(test_dir/'predictions.jsonl')
        if '_geq_' in method:
            history=rows(directory/'history.jsonl');human_epoch=state['epoch']
        else:
            history=rows(directory/'history.jsonl');human_epoch=state['epoch']+1
        entries.append(dict(e,full_test_index=i,full_test_directory=str(test_dir),
                            training_directory=str(directory),best_epoch_human=human_epoch,
                            last_training_epoch=history[-1]['epoch'],full_test=full_results[method]['values'],
                            oracle_presence={k:float(oracle[method][f'oracle_G-mIoU@{k}']) for k in (1,3)}))
        del state
    assert len(entries)==6
    split_info={};feature_hashes={};standard_queries=[]
    for split in ('train','val','test'):
        p=DATA_ROOT/'data/label/Standard'/f'{split}.jsonl';data=rows(p);standard_queries+=data
        copy(p,Path('snapshot/labels/Standard')/f'{split}.jsonl')
        split_info[split]=dict(path=str(p),sha256=sha(p),rows=len(data),positive=sum(bool(d['relevant_windows']) for d in data),
                               negative=sum(not d['relevant_windows'] for d in data),normalized_video_stems=len({Path(d['vid']).stem for d in data}))
    da=read(PROJECT/'soccergmr_full_test_handoff_20261102/DATA_AUDIT.json')
    for key,subpath in [('available_decodable_test','Full-Decodable/test.jsonl'),('original_test','Original-Full/test.jsonl')]:
        p=Path(da[key]['path']);copy(p,Path('snapshot/labels')/subpath)
    for key in ('feature_manifest','feature_verification','feature_exclusions'):
        p=Path(da[key]);copy(p,Path('snapshot/full_feature_protocol')/p.name)
    print('CHECKPOINTS_AND_SNAPSHOTS_VERIFIED; hashing Standard features',flush=True)
    paths=set()
    for d in standard_queries:
        for kind in ('slowfast','clip'):paths.add(DATA_ROOT/'Soccergmr'/kind/f'{d["vid"]}.npz')
        paths.add(DATA_ROOT/'Soccergmr/clip_text'/f'qid{d["qid"]}.npz')
    for p in sorted(paths):feature_hashes[str(p)]=sha(p)
    standard_feature_count=len(feature_hashes)
    full_feature_hashes=read(FULL/'FEATURE_SHA256.json')
    for p,h in full_feature_hashes.items():assert sha(p)==h
    feature_hashes.update(full_feature_hashes)
    dump(HERE/'FEATURE_SHA256.json',feature_hashes)
    standard_stats=read(CORE/'runs/cg_detr/baseline/experiment_config.json')
    multi_stats=read(CORE/'runs/cg_detr/multi/experiment_config.json')
    cg_code={str(p):sha(p) for p in (CORE/'run.py',CORE/'multiroute.py',CORE.parent/'cg_detr/train_gmr.py',
                                    CORE.parent/'cg_detr/gmr_source/cg_detr/model.py',KIT/'geq_model.py',KIT/'run_study.py',KIT/'native_adapter.py',KIT/'validation_selection.py')}
    drift=[]
    for variant in ('baseline','multi'):
        for mode in ('frozen','full'):
            conf=read(PROJECT/'geq_protocol_experiments/20261031/cg_detr'/variant/mode/'CONFIG.json')
            for group in ('code_sha256','native_source_sha256'):
                for name,h in conf[group].items():
                    p=KIT/name if group=='code_sha256' else Path(name)
                    if sha(p)!=h:drift.append(dict(variant=variant,mode=mode,path=str(p),recorded=h,current=sha(p)))
    full_gt=rows(da['available_decodable_test']['path'])
    env=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),torch=torch.__version__,
             cuda_version=torch.version.cuda,packages={d.metadata['Name']:d.version for d in importlib.metadata.distributions()})
    dump(HERE/'ENVIRONMENT.json',env)
    manifest=dict(scope='CG-DETR current six Standard-trained methods; handoff only; no training/inference launched',
                  primary_method='multi_geq_full',python=sys.executable,checkpoints=entries,
                  standard_splits=split_info,standard_feature_root=str(DATA_ROOT/'Soccergmr'),
                  standard_feature_files=standard_feature_count,full_feature_files=len(full_feature_hashes),
                  feature_hash_file='FEATURE_SHA256.json',feature_hash_file_sha256=sha(HERE/'FEATURE_SHA256.json'),
                  full_decodable=da['available_decodable_test'],original_full=da['original_test'],
                  full_raw_vid_strings=len({d['vid'] for d in full_gt}),full_normalized_video_stems=len({Path(d['vid']).stem for d in full_gt}),
                  full_feature_root=da['feature_root'],full_feature_protocol=da['feature_protocol'],
                  full_feature_manifest=da['feature_manifest'],full_feature_manifest_sha256=da['feature_manifest_sha256'],
                  original_full_exclusions=da['excluded_test_rows'],full_input_caveats=read(FULL/'INPUT_AUDIT.json')['over_75_steps']+read(FULL/'INPUT_AUDIT.json')['temporal_mismatches_gt_vs_features'],
                  training_native_baseline=standard_stats,training_native_multi=multi_stats,
                  important_code_sha256=cg_code,historical_geq_code_drift=drift,
                  live_files=live,snapshots=snapshots,environment_file='ENVIRONMENT.json',
                  git_head_backbone_repo='39ab0eb74427709851476b2bb86b698c8a3f4186',
                  project_is_git_repository=False,
                  limitations=['Weights and large features are referenced, not duplicated. Source and small metadata are copied.',
                               'The frozen current checkpoints reproduce existing results; fresh training is not guaranteed bitwise identical.',
                               'Full Test has already informed research discussion; future improvements on it are exploratory, not a fresh untouched Test.'])
    dump(HERE/'MANIFEST.json',manifest)
    dump(HERE/'CHECKPOINTS_CG_DETR.json',dict(backbone='cg_detr',count=6,checkpoints=entries))
    result_rows=[]
    for e in entries:
        v=e['full_test'];result_rows.append(dict(method=e['method'],mAP_percent=v['mAP'],
            **{f'G-mIoU@{k}@{t}':v[f'G-mIoU@{k}@tau={t}'] for k in (1,3) for t in (.4,.5,.6)},
            **{f'oracle_G-mIoU@{k}':e['oracle_presence'][k] for k in (1,3)}))
    with (HERE/'CG_FULL_RESULTS.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,list(result_rows[0]));w.writeheader();w.writerows(result_rows)
    print(json.dumps(dict(passed=True,checkpoints=6,snapshots=len(snapshots),standard_features=standard_feature_count,
                          full_features=len(full_feature_hashes),historical_source_drift=drift,training_started=False,inference_started=False)),flush=True)

if __name__=='__main__':main()
