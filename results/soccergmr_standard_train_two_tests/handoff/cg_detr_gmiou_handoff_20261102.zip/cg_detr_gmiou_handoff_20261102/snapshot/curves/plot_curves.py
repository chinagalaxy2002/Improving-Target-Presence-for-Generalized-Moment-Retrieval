#!/usr/bin/env python3
"""Offline fixed-threshold sweep of immutable Full-Decodable predictions."""
import csv
import fcntl
import hashlib
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
OFFICIAL = Path('/home/guoxiangyu/GMR_Unseen/experiments/table2_repro_20261022/shared')
sys.path.insert(0, str(OFFICIAL))
from official_eval.metrics import (_clean_pred_windows, _compute_set_iou_score,
    compute_G_mIoU, get_existence_score, prepare_submission_for_gmiou)

BACKBONES = dict(moment_detr='Moment-DETR', eatr='EaTR', qd_detr='QD-DETR', cg_detr='CG-DETR')
METHODS = ['gmr','gmr_geq_frozen','gmr_geq_full','multi','multi_geq_frozen','multi_geq_full']
LABELS = ['GMR (baseline)', 'GMR + GEQ Frozen', 'GMR + GEQ Full',
          'GMR + Multi', 'GMR + Multi + GEQ Frozen', 'GMR + Multi + GEQ Full']
STYLES = [('#4D4D4D','-','o'),('#0072B2','--','s'),('#009E73','-.','^'),
          ('#CC79A7','-','D'),('#E69F00','--','v'),('#D55E00','-.','P')]
THRESHOLDS = [i/100 for i in range(101)]
KS = [1,3]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path): return json.loads(Path(path).read_text())
def rows(path): return [json.loads(l) for l in Path(path).read_text().splitlines() if l.strip()]
def dump(path, obj): Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')

def write_csv(path, data):
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,list(data[0])); writer.writeheader(); writer.writerows(data)

def collect():
    completion=read(SOURCE/'COMPLETE.json')
    assert completion['passed'] and completion['formal_completed']==24
    for name,h in completion['artifacts_sha256'].items(): assert sha(SOURCE/name)==h, name
    input_audit=read(SOURCE/'INPUT_AUDIT.json')
    gt_path=next(Path(p) for p in input_audit['input_sha256'] if 'full_decodable/Full/test.jsonl' in p)
    assert sha(gt_path)==input_audit['input_sha256'][str(gt_path)]
    gt=rows(gt_path); assert len(gt)==2970
    result_index={(r['backbone'],r['method']):r for r in read(SOURCE/'RESULTS.json')}
    curves={}; checks=[]; input_hashes={str(gt_path):sha(gt_path),str(SOURCE/'RESULTS.json'):sha(SOURCE/'RESULTS.json'),
                                       str(SOURCE/'COMPLETE.json'):sha(SOURCE/'COMPLETE.json')}
    data=[];oracle_rows=[]
    for backbone in BACKBONES:
        for method,label in zip(METHODS,LABELS):
            directory=SOURCE/'runs'/backbone/method
            marker=read(directory/'COMPLETE.json')
            for name,key in [('predictions.jsonl','predictions_sha256'),('metrics.json','metrics_sha256')]:
                path=directory/name
                assert sha(path)==marker[key]
                input_hashes[str(path)]=sha(path)
            assert marker['identity']['gt_sha256']==sha(gt_path)
            predictions=rows(directory/'predictions.jsonl')
            index={p['qid']:p for p in predictions}
            assert len(index)==len(predictions)==2970 and set(index)=={d['qid'] for d in gt}
            scores=[]; rejected=[]; accepted={k:[] for k in KS}
            for d in gt:
                p=index[d['qid']]
                assert (p['vid'],p['query'])==(d['vid'],d['query'])
                score,source=get_existence_score(p)
                assert source=='pred_exist_score' and np.isfinite(score)
                scores.append(score)
                clean=_clean_pred_windows(p['pred_relevant_windows'],max_pred_windows=10)
                windows=[[w[0],w[1]] for w in clean]
                rejected.append(_compute_set_iou_score([],d['relevant_windows']))
                for k in KS: accepted[k].append(_compute_set_iou_score(windows[:k],d['relevant_windows']))
            # Gating changes only which of these two per-query contributions
            # applies. Python summation follows official GT order and rounding.
            ys={k:[] for k in KS}
            for t in THRESHOLDS:
                for k in KS:
                    mean=sum(a if s>t else r for a,s,r in zip(accepted[k],scores,rejected))/len(gt)
                    ys[k].append(round(100*mean,2)/100)
            # Independently invoke the official gate + aggregate at the endpoints
            # and at every threshold already published in the formal table.
            for t in (0.,.4,.5,.6,1.):
                gated,_=prepare_submission_for_gmiou(predictions,cls_threshold=t,max_pred_windows=10)
                official=compute_G_mIoU(gated,gt,k_list=KS)
                for k in KS:
                    value=ys[k][int(round(100*t))]
                    assert abs(value-official[f'G-mIoU@{k}']/100)<1e-12
                    if t in (.4,.5,.6):
                        published=result_index[(backbone,method)]['values'][f'G-mIoU@{k}@tau={t}']
                        assert abs(value-published)<1e-12
            # Oracle presence changes only the binary presence decision: all
            # positive queries keep the same cleaned, ordered localization
            # candidates, while every negative query is rejected.
            oracle_submission=[dict(p,pred_exist_score=float(bool(d['relevant_windows'])))
                               for d in gt for p in [index[d['qid']]]]
            oracle_gated,_=prepare_submission_for_gmiou(oracle_submission,cls_threshold=.5,max_pred_windows=10)
            oracle_official=compute_G_mIoU(oracle_gated,gt,k_list=KS)
            oracle_row=dict(backbone=backbone,method=method,label=label)
            for k in KS:
                score=round(100*sum(a if d['relevant_windows'] else r
                                   for a,d,r in zip(accepted[k],gt,rejected))/len(gt),2)/100
                assert abs(score-oracle_official[f'G-mIoU@{k}']/100)<1e-12
                assert score+1e-12>=max(ys[k])
                oracle_row[f'oracle_G-mIoU@{k}']=score
            oracle_rows.append(oracle_row)
            curves[(backbone,method)]=ys
            checks.append(dict(backbone=backbone,method=method,rows=2970,
                               official_spot_checks=[0.,.4,.5,.6,1.],published_points_exact=True,
                               oracle_presence_official_exact=True))
            for i,t in enumerate(THRESHOLDS):
                data.append(dict(backbone=backbone,method=method,label=label,threshold=t,
                                 **{f'G-mIoU@{k}':ys[k][i] for k in KS}))
            print('VERIFIED',backbone,method,flush=True)
    return curves,data,checks,input_hashes,oracle_rows

def panel(ax, curves, backbone, k, oracle_ceilings):
    for method,label,(color,ls,marker) in zip(METHODS,LABELS,STYLES):
        ax.plot(THRESHOLDS,curves[(backbone,method)][k],label=label,color=color,
                linestyle=ls,linewidth=1.65,marker=marker,markersize=4,
                markevery=[10,30,40,50,60,70,90],markerfacecolor='white',markeredgewidth=1,
                zorder=4 if method=='gmr' else 3)
    ceiling=oracle_ceilings[(backbone,k)]
    ax.axhline(ceiling,color='#111827',linestyle=(0,(5,3)),linewidth=1.2,zorder=2)
    ax.text(.98,ceiling+.008,f'Oracle ceiling = {ceiling:.4f}',
            transform=ax.get_yaxis_transform(),ha='right',va='bottom',fontsize=8.3,color='#111827',
            bbox=dict(facecolor='white',edgecolor='none',alpha=.9,pad=1.2))
    for t in (.4,.5,.6): ax.axvline(t,color='#CBD5E1',lw=.65,zorder=0)
    ax.set_xlim(0,1);ax.set_ylim(0,.65)
    ax.set_xticks(np.arange(0,1.01,.2));ax.set_yticks(np.arange(0,.61,.1))
    ax.set_xlabel(r'Existence threshold $\tau$');ax.set_ylabel(f'G-mIoU@{k} (0–1)')
    ax.grid(axis='y',color='#E2E8F0',linewidth=.6)
    ax.spines[['top','right']].set_visible(False)
    ax.spines[['bottom','left']].set_color('#94A3B8')
    ax.tick_params(length=3,color='#94A3B8')

def map_legend(fig,ax,backbone,maps,anchor=.035,loc='lower center'):
    handles,_=ax.get_legend_handles_labels()
    labels=[f'{label}  |  mAP {maps[(backbone,method)]:.2f}%'
            for method,label in zip(METHODS,LABELS)]
    return fig.legend(handles,labels,loc=loc,bbox_to_anchor=(.5,anchor),ncol=3,
                      frameon=False,fontsize=8.3,handlelength=2.8,columnspacing=1.5)

def decorate(fig,axes,title,bottom=.22,top=.79):
    fig.suptitle(title,fontsize=13,fontweight='bold',y=.98)
    fig.text(.5,.91,'Standard-trained checkpoints → SoccerGMR Full-Decodable Test (2970/2986)',ha='center',fontsize=9)
    fig.text(.5,.012,'Dashed horizontal line: max oracle-presence G-mIoU over six methods; fixed localization. mAP: %. No threshold selection.',
             ha='center',fontsize=8,color='#475569')
    fig.subplots_adjust(left=.08,right=.985,bottom=bottom,top=top,hspace=.48,wspace=.24)

def save(fig,stem):
    fig.savefig(HERE/(stem+'.png'),dpi=220)
    fig.savefig(HERE/(stem+'.pdf'),metadata={'CreationDate':None,'ModDate':None})
    fig.savefig(HERE/(stem+'.svg'))

def main():
    with (HERE/'PLOT.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        curves,data,checks,inputs,oracle_rows=collect()
        oracle_ceilings={(b,k):max(r[f'oracle_G-mIoU@{k}'] for r in oracle_rows if r['backbone']==b)
                         for b in BACKBONES for k in KS}
        ceiling_rows=[dict(backbone=b,metric=f'G-mIoU@{k}',oracle_ceiling=oracle_ceilings[(b,k)],
                           methods=';'.join(r['method'] for r in oracle_rows
                                            if r['backbone']==b and r[f'oracle_G-mIoU@{k}']==oracle_ceilings[(b,k)]))
                      for b in BACKBONES for k in KS]
        write_csv(HERE/'ORACLE_PRESENCE_BY_METHOD.csv',oracle_rows)
        write_csv(HERE/'ORACLE_CEILINGS.csv',ceiling_rows)
        results=read(SOURCE/'RESULTS.json')
        maps={(r['backbone'],r['method']):r['values']['mAP'] for r in results}
        map_rows=[dict(backbone=b,method=m,label=label,mAP_percent=maps[(b,m)])
                  for b in BACKBONES for m,label in zip(METHODS,LABELS)]
        write_csv(HERE/'MAP_BY_METHOD.csv',map_rows)
        write_csv(HERE/'CURVES.csv',data)
        write_csv(HERE/'FORMAL_040506_POINTS.csv',[d for d in data if d['threshold'] in (.4,.5,.6)])
        plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,
                             'axes.titlesize':11,'xtick.labelsize':8,'ytick.labelsize':8,
                             'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none'})
        with PdfPages(HERE/'BY_BACKBONE.pdf',metadata={'CreationDate':None,'ModDate':None}) as pdf:
            for b,name in BACKBONES.items():
                fig,axes=plt.subplots(1,2,figsize=(11.4,4.6),sharey=True)
                for ax,k in zip(axes,KS):panel(ax,curves,b,k,oracle_ceilings);ax.set_title(f'G-mIoU@{k}')
                decorate(fig,axes,f'{name}: G-mIoU versus existence threshold')
                map_legend(fig,axes[0],b,maps)
                save(fig,b);pdf.savefig(fig);plt.close(fig)
        fig,axes=plt.subplots(4,2,figsize=(11.4,14.2),sharex=True,sharey=True)
        for i,(b,name) in enumerate(BACKBONES.items()):
            for j,k in enumerate(KS):
                panel(axes[i,j],curves,b,k,oracle_ceilings);axes[i,j].set_title(f'{name} · G-mIoU@{k}')
                if i<3:axes[i,j].set_xlabel('')
        decorate(fig,axes,'G-mIoU sensitivity by backbone · mAP by method',bottom=.15,top=.89)
        fig.subplots_adjust(hspace=.68)
        fig.texts[1].set_y(.945)
        for i,b in enumerate(BACKBONES):
            y=axes[i,0].get_position().y0-(.055 if i==3 else .012)
            map_legend(fig,axes[i,0],b,maps,anchor=y,loc='upper center')
        save(fig,'ALL_BACKBONES');plt.close(fig)
        for k in KS:
            fig,axes=plt.subplots(4,1,figsize=(11.4,14.2),sharex=True,sharey=True)
            for i,(ax,(b,name)) in enumerate(zip(axes,BACKBONES.items())):
                panel(ax,curves,b,k,oracle_ceilings);ax.set_title(name)
                if i<3:ax.set_xlabel('')
            decorate(fig,axes,f'G-mIoU@{k} versus existence threshold · mAP by method',bottom=.15,top=.89)
            fig.subplots_adjust(hspace=.68)
            fig.texts[1].set_y(.945)
            for i,b in enumerate(BACKBONES):
                y=axes[i].get_position().y0-(.055 if i==3 else .012)
                map_legend(fig,axes[i],b,maps,anchor=y,loc='upper center')
            save(fig,f'G_MIOU_AT_{k}_BY_BACKBONE');plt.close(fig)
        max_value=max(d[f'G-mIoU@{k}'] for d in data for k in KS)
        assert max_value<.6 and all(0<=d[f'G-mIoU@{k}']<=1 for d in data for k in KS)
        caption=('G-mIoU changes with the existence threshold, with different profiles across backbones and methods. '
                 'Panels show six Standard-trained checkpoints per backbone evaluated on SoccerGMR Full-Decodable Test '
                 '(2970 of the original 2986 queries; 1633 positive and 1337 negative). Predictions are accepted only when '
                 'their existence score exceeds τ; otherwise the predicted set is empty. The curves use a fixed 0.01 grid '
                 'over [0,1], in the original 0–1 metric scale; the displayed y range is [0,0.65]. Vertical guides mark the '
                 'three formally reported thresholds 0.4, 0.5 and 0.6. Lines connect sampled thresholds; no threshold is '
                 'selected using Test. Each backbone has its own method legend with the corresponding formal Test mAP '
                 'in percent, shown once per method because mAP is independent of the existence threshold. GEQ Full '
                 'denotes the existing fine-tuning mode, distinct from the Full dataset. The dashed horizontal line '
                 'shows the largest oracle-presence G-mIoU among the six methods for that backbone and k: all negatives '
                 'are rejected and all positives retain their original top-k localization candidates. It is an upper '
                 'bound conditional on these fixed candidates, rather than a measured threshold-sweep maximum.')
        text=['# 按骨干绘制的G-mIoU阈值曲线','',
              '使用本轮24项正式Full-Decodable Test逐查询预测离线绘图，不重新推理、不训练、不选阈值。',
              '横轴为存在性阈值τ，范围0–1、步长0.01；纵轴为G-mIoU原始0–1标度，统一显示0–0.65以便骨干间比较。每个骨干左图为@1、右图为@3，包含全部六种方法。颜色、线型和标记同时区分方法。灰色竖线为正式报告的0.4/0.5/0.6。','',
              '每个子图有且仅有一条黑色水平虚线，标注“Oracle ceiling”。该线为同骨干六种方法中，存在性判断完全正确时可恢复G-mIoU的最高值：全部负例拒绝、全部正例保留原定位候选，候选边界、顺序、置信度均不变。它是当前固定定位候选下的理论可恢复上限，不是阈值扫描实测峰值，也不使用真实GT生成或替换定位候选。@1/@3分别独立计算。','',
              '[每种方法的oracle值](ORACLE_PRESENCE_BY_METHOD.csv) · [八个子图的上限横线](ORACLE_CEILINGS.csv)','',
              '每个骨干均有独立图例，方法名后标注本轮正式Test的mAP（%）。mAP按正例未门控候选计算，与存在性阈值无关，因此每个方法只列一次，并由@1/@3两幅曲线共享。24个mAP全部直接取自已核验的RESULTS.json，数值见[方法mAP CSV](MAP_BY_METHOD.csv)。','',
              '[总览 PNG](ALL_BACKBONES.png) · [总览 PDF](ALL_BACKBONES.pdf) · [总览 SVG](ALL_BACKBONES.svg) · [四骨干分页 PDF](BY_BACKBONE.pdf) · [全部曲线 CSV](CURVES.csv) · [正式三点 CSV](FORMAL_040506_POINTS.csv)','',
              '![总览](ALL_BACKBONES.png)','', '| 骨干 | PNG | PDF | SVG |','|---|---|---|---|']
        for b,name in BACKBONES.items():text.append(f'| {name} | [PNG]({b}.png) | [PDF]({b}.pdf) | [SVG]({b}.svg) |')
        text+=['','[仅G-mIoU@1四骨干图](G_MIOU_AT_1_BY_BACKBONE.pdf) · [仅G-mIoU@3四骨干图](G_MIOU_AT_3_BY_BACKBONE.pdf)','',
               '全部24配置在τ=0、0.4、0.5、0.6、1上与官方gate+G-mIoU直接重算一致；其中0.4/0.5/0.6与已发布表格全部一致（24×3×2=144个指标值）。计算复用官方窗口清理和逐查询集合IoU，仅缓存接受/拒绝两种贡献，判定严格使用score>τ。曲线是固定网格的描述性扫描，不推荐或重选Test阈值。','',
               '数据范围仍是2970/2986；历史排除的16条、原生75步视频截断和3段时长偏差均保留，详见[原正式报告](../README.md)。图中没有混入Standard Test或历史协议结果。全拒绝端点τ=1对所有方法均为1337/2970≈0.4502，反映G-mIoU对正确拒绝负例的计分。','',
               '图注：'+caption,'',
               '复现：`/home/guoxiangyu/miniconda3/envs/gmr/bin/python -B plot_curves.py`。输入/输出哈希及核验见[PROVENANCE.json](PROVENANCE.json)。']
        (HERE/'README.md').write_text('\n'.join(text)+'\n')
        code={str(p):sha(p) for p in (Path(__file__),OFFICIAL/'official_eval/metrics.py',OFFICIAL/'official_eval/utils.py')}
        outputs={p.name:sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ('.csv','.pdf','.png','.svg','.md')}
        assert all(sha(p)==h for p,h in inputs.items())
        dump(HERE/'PROVENANCE.json',dict(passed=True,scope='Standard-trained checkpoints → SoccerGMR Full-Decodable Test (2970/2986)',
             methods=24,thresholds=THRESHOLDS,metrics=['G-mIoU@1','G-mIoU@3'],metric_unit='0-1',
             threshold_selection=False,inference_rerun=False,original_inputs_unchanged=True,
             input_sha256=inputs,code_sha256=code,output_sha256=outputs,checks=checks,
             maximum_plotted_value=max_value,plot_y_limits=[0,.65],
             oracle_definition='Perfect existence decisions; original positive localization candidates retained; all negatives rejected. One ceiling line per subplot is the maximum over the six fixed methods.',
             oracle_presence_values=oracle_rows,oracle_ceiling_lines=ceiling_rows,
             map_unit='percent',map_source=str(SOURCE/'RESULTS.json'),map_values=map_rows,
             design=dict(type='experimental-results',paradigm='line',encoding='color + line style + marker',
                         vector_exports=['PDF','SVG'],display_units='0-1',no_errorbars='One fixed checkpoint per method; no repeated-run variance available')))
        print('DONE: 24 methods × 101 thresholds × 2 metrics; original three points verified.',flush=True)

if __name__=='__main__':main()
