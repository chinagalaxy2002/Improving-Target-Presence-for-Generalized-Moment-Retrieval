# Standard-trained checkpoints → SoccerGMR Full-Decodable Test (2970/2986)

**24/24项正式Test已完成；每项覆盖2970/2970条（1633正例、1337负例），无新增跳过。原始Full Test为2986条，历史16条未覆盖（5正例、11负例），本结果不代表原始Full完整覆盖。**

四骨干均使用交接清单的原有Standard Train/Val best，SHA256逐文件核验、完整state_dict严格加载。全程eval()、禁用梯度，无训练、微调、重新选模或Test调参。GEQ Full是既有微调模式，和本次Full数据集不同。24项小批推理预检全部通过后，先完成8个GMR/Multi父模型的Full定位候选，再执行16项GEQ。

[主表 PNG](FULL_DECODABLE_TEST.png) · [主表 PDF](FULL_DECODABLE_TEST.pdf) · [全部表格 PDF](ALL_TABLES.pdf) · [LaTeX](ALL_TABLES.tex) · [CSV](RESULTS.csv) · [相对GMR增减](DELTAS_VS_GMR.csv) · [结果 JSON](RESULTS.json) · [全部官方指标及明细](OFFICIAL_ALL_METRICS.json)

![正式Test主表](FULL_DECODABLE_TEST.png)

公共指标每行只列一次。存在性阈值τ固定为0.4、0.5、0.6；定位mAP/mR在正例未门控候选上计算，AUROC/N-acc/Rej-F1/G-mIoU在完整正负域计算。N-acc=TN/负例数，不是Acc整体准确率。G-mIoU和其差值保持0–1；其余指标为百分数、差值为百分点。下方括号一律为“方法−同骨干GMR”；绿色增益、红色下降、灰色持平，GMR浅蓝加粗。CSV保留源精度，表格再四舍五入。官方Acc/Rej-P/Rej-R及其他定位指标在附表中完整报告。

[额外官方定位指标](OFFICIAL_LOCALIZATION_EXTRA.pdf) · [额外官方阈值指标](OFFICIAL_THRESHOLD_EXTRA.pdf)

八项Frozen逐张量验证原生权重与父检查点相同；正式预测直接复用对应父模型本轮Full候选的边界、顺序和分数，仅替换pred_exist_score。候选完全相同，官方mAP/mR/mR+/mIoU/mIoU+全部逐项一致，详见[AUDIT.json](AUDIT.json)。GEQ Full则严格加载其完整best（包含更新后的原生权重），独立生成候选。

输入使用Full独立qid文本特征，未复用Standard预测或文本特征；GT直接读取relevant_windows，不从moment再次扩窗。CLIP/SlowFast各自L2归一化，Moment-DETR按CLIP→SlowFast拼接，其余按SlowFast→CLIP；保留原TEF、32 token上限、10候选、排序、两秒取整及各骨干原生后处理。所有唯一特征的维度、有限值、时间步及SHA256已核验；推理时每批额外检查mask、非空有效token及输出有限性。

需要保留的输入限制：原配置视频上限75步（每步2秒）。Full中两段94/104步视频使用原配置截断前75步，仍按原duration缩放输出；Moment-DETR另外保留原生最大150秒时间后处理。没有调整模型序列上限、重采样或改写标签。此处“2970条覆盖”指每个查询均完成推理，不表示每段视频的全部时间范围都进入编码器。另有3段特征时长与标签duration相差超过2秒，沿用原生duration缩放；这些偏差会影响时序定位解释，未按Test修正或排除。详细视频、qid和长度见[输入审计](INPUT_AUDIT.json)。

原始Full Test与Standard Test共享1036个规范化视频stem+查询对（461段视频）；与Standard Train/Val的视频stem初查交集均为0。两组Test结果不能视为相互独立的实验样本。

历史16条排除来自两个ffprobe失败的视频，保持原始数据版本不变，逐条如下（完整记录：[JSONL](EXCLUDED_ORIGINAL_FULL_TEST_16.jsonl)）：

| qid | 视频 | GT数 |
|---:|---|---:|
| 19877 | WC2022_3869685_1_2240s_2390s.mp4 | 2 |
| 20318 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 20345 | AC_Ajaccio_Lens_QsKULW3B_1_1960s_2110s.mkv | 0 |
| 20356 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 20739 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 20911 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 20984 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 21080 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 21099 | WC2022_3869685_1_2240s_2390s.mp4 | 1 |
| 21322 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 21456 | AC_Ajaccio_Lens_QsKULW3B_1_1960s_2110s.mkv | 1 |
| 21499 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 21559 | WC2022_3869685_1_2240s_2390s.mp4 | 1 |
| 21731 | WC2022_3869685_1_2240s_2390s.mp4 | 1 |
| 21747 | WC2022_3869685_1_2240s_2390s.mp4 | 0 |
| 21798 | AC_Ajaccio_Lens_QsKULW3B_1_1960s_2110s.mkv | 0 |

每项[runs/](runs/)含逐查询预测、官方三阈值指标、严格加载/小批预检、输入身份及完成标记；[logs/](logs/)保留日志。[INPUT_AUDIT.json](INPUT_AUDIT.json)含检查点、GT、manifest、代码及输入审计，[FEATURE_SHA256.json](FEATURE_SHA256.json)含全部4616个唯一特征哈希。任务使用TASK.lock防重，合法结果仅在输入、代码、检查点和产物哈希一致时复用。

复现：在本目录使用`/home/guoxiangyu/miniconda3/envs/gmr/bin/python -B run_all.py`。入口只执行推理；GPU调度计入其他CUDA进程，每卡至多2项、全机至多4项。`build_report.py`可离线重建表格。
