# CG-DETR测试交接

本文件对应当前六方法、Standard训练得到的best。**Full数据集**和**GEQ Full微调模式**分别是数据与方法两个概念。

## 已完成的评估

正式Full测试根目录：`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/soccergmr_full_test_20261102/`。

CG六方法记录在`runs/cg_detr/{gmr,gmr_geq_frozen,gmr_geq_full,multi,multi_geq_frozen,multi_geq_full}/`。每目录有：

- `predictions.jsonl`：本轮独立Full推理的2970条完整逐查询预测。
- `metrics.json`：官方0.4/0.5/0.6三阈值全套输出；官方原始G-mIoU字段仍是百分数。
- `PREFLIGHT.json`：严格加载、正/负/多GT及长序列样本推理校验。
- `COMPLETE.json`：检查点/GT/代码/特征/预测/指标哈希、原生选项、覆盖、Frozen核验。

聚合结果为`RESULTS.json/CSV`，图表为`ALL_TABLES.pdf`；G-mIoU在这些聚合文件中已经转换到0–1，**不要再除100**。图及oracle上限在`gmiou_threshold_curves/`，CG单图为`cg_detr.png/pdf/svg`。交接包保存CG结果`CG_FULL_RESULTS.csv`及`snapshot/full_test_records/`小型证据；预测及大文件仍按原绝对路径引用。

Standard Test结果源头是各训练目录的`test_metrics.json/test_predictions.jsonl`；当前整理主表为`/home/guoxiangyu/charades-multi-geq-worktree/results/test_all_thresholds/README.md`。该目录名包含Charades，但其SoccerGMR当前六方法表可用于身份核对；不混入它的Charades或历史附表。

| 方法 | Standard Test mAP（%） | Full-Decodable Test mAP（%） |
|---|---:|---:|
| GMR | 16.09 | 13.58 |
| GMR+GEQ Frozen | 16.09 | 13.58 |
| GMR+GEQ Full | 16.58 | 14.01 |
| GMR+Multi | 16.59 | 15.48 |
| GMR+Multi+GEQ Frozen | 16.59 | 15.48 |
| GMR+Multi+GEQ Full | 18.59 | 15.93 |

## 数据身份与覆盖

原始Full Test：`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/generalized-moment-retrieval/data/label/Full/test.jsonl`，2986条、1638正/1348负，SHA256 `fc7955218d02a7269fc2a7885a0f004bbd696be42e95d009441573a6b1a365fc`。

本轮Full-Decodable Test：`/home/guoxiangyu/GMR_Unseen_s4_minus_fusion_baseline_20261019/experiments/gmr-Global-Eventquery/data/full_decodable/Full/test.jsonl`，2970条、1633正/1337负，SHA256 `271951cd2ae87d93959e0abc9c67f5243a033e36bdab155c5981064891517851`。

特征：`/home/guoxiangyu/VLMbasedIter_momentretrival/generalized-moment-retrieval/Soccergmr/Full_features/`，协议`soccer_full_lighthouse_standard_bn45_v1`，manifest SHA256 `a56bea0061a65076b05e9556f15b4496ef5d0839ce3ef02a7195009e43a69a8b`。同时核对`.extraction/VERIFIED.json`及`EXCLUSIONS.json`；参考`snapshot/full_feature_protocol/`和MANIFEST。

16条历史排除来自两个无法ffprobe的视频，完整原始记录在MANIFEST的`original_full_exclusions`和旧正式目录`EXCLUDED_ORIGINAL_FULL_TEST_16.jsonl`。不增加静默跳过；本轮结果只能叫“Standard-trained checkpoints → SoccerGMR Full-Decodable Test (2970/2986)”。

视频计数的口径须区分：2970条中有1008种原始`vid`字符串，去掉扩展名后为823个特征stem。有的视频同时以带扩展名和不带扩展名的字符串出现；**只在特征路径查找时去扩展名，GT和预测中的vid身份保留原值**。4616个唯一Full特征文件由823×2个视频流文件及2970个qid文本文件组成。

已知输入限制必须随结果报告：两段视频94/104步按原配置截断为75步，仍按原duration输出；另有3段视频的特征时长与label duration相差超过2秒。MANIFEST保存具体视频、步数和相关qid。严格复现时沿用；若研究修正时间处理，另立输入/评测协议，并对比较模型作一致处理。

## CG专用推理逻辑

独立eval-only入口：`/home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/soccergmr_full_test_20261102/eval_only.py`。

它复用原模型构造/导出，但显式创建`FullSoccer`并替换Full标签及特征。不能仅把旧`Adapter.dataset('test')`的输出名改成Full，因为该dataset方法仍是Standard路径。不能复用Standard qid文本或预测。

按SlowFast2304→CLIP512→TEF2拼接，两流各自L2归一化；文本前32 token、512维；视频最长75步。原生10个候选，softmax foreground置信度降序，cxw转边界后按duration缩放、两秒取整、clamp到该视频duration。保持原生无额外NMS的导出，不引入新候选数量或按Test调整后处理。

推理必须完整严格加载清单state_dict、`model.eval()`、`torch.no_grad()`，不给CG传targets，使用`vid=None`保持合成负配对关闭，不产生`o2m_outputs`。

Frozen的正式导出：先生成父GMR或父Multi在**同一Full输入**上的候选，再复制父预测全部字段，仅替换`pred_exist_score`。冻结模型内原生参数要逐张量等于父best；边界/顺序/置信度完全相同，官方mAP/mR/mR+/mIoU/mIoU+必须逐项一致。不能取GEQ Full模型的候选给Frozen使用。

## 合法复用当前六项结果

先在交接目录运行：

```bash
/home/guoxiangyu/miniconda3/envs/gmr/bin/python -B /home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/cg_detr_gmiou_handoff_20261102/verify_handoff.py
```

若只需复查旧CG结果，旧eval入口index对应：18 GMR、19 GMR+GEQ Frozen、20 GMR+GEQ Full、21 Multi、22 Multi+GEQ Frozen、23 Multi+GEQ Full。

```bash
cd /home/guoxiangyu/ImprovingGeneralizedMomentRetrieval/soccergmr_full_test_20261102
CUDA_VISIBLE_DEVICES=0 /home/guoxiangyu/miniconda3/envs/gmr/bin/python -B eval_only.py --index 23 --phase formal
```

这条命令在完成标记及全部输入身份一致时只输出`REUSED_VALID_COMPLETION`，**不是对新权重重新测试**。它还会核验原正式代码身份；代码漂移时应使用保存的快照对照，不允许绕过校验。不要调用`run_all.py`去无差别派发另外三个骨干。

## 新方法的Test入口要求

不能改旧清单让旧结果目录变成新模型，也不能直接复制`eval_only.py/common.py`到任意目录就运行：`PROJECT=HERE.parent`、旧输出根、所有24项preflight/父任务依赖和代码身份校验都需要在**新的独立入口**中显式重设。快照供阅读/复用函数，不是声称任意搬动后仍可原样运行。

新入口只处理CG，显式给出checkpoint、SHA256、父模型、split、GT和特征路径、输出根、代码版本。复用已验证的数据转换和原生预测逻辑，首先做真实正/负/多GT及长视频的小批strict-load推理，记录为调试结果；再完成整套Test后写完成标记。新Frozen依赖该实验父模型的新Full预测。旧官方GT/特征/原生候选协议不变。

每个输出保存predictions、三阈值官方metrics、覆盖、输入/代码/输出SHA256及日志。命名显式标注新方法版本、初始化、训练数据及测试划分；不得将测试小批或仅启动队列称为正式Test。

## 指标、单位与oracle横线

- 定位mAP/mR在正例未门控候选上计算；AUROC/N-acc/Rej-F1/G-mIoU在完整正负域计算。
- 官方gate严格使用`score > τ`为存在，`score <= τ`为空集。默认正式τ=0.4/0.5/0.6，不按Test挑阈值。
- N-acc=TN/N，不是整体Acc；G-mIoU@1/@3报告三点。G-mIoU展示0–1，其余百分数，增减以同骨干GMR为基准；固定公共指标每行只列一次。
- 官方集合IoU对空/空赋1、一空赋0；两集合非空时用原实现贪心匹配与集合归一化。不要换成单GT最高IoU平均。官方源在`snapshot/official_eval/`。
- oracle存在性保持每种模型的定位候选不变，只让正例全部接收、负例全部拒绝。CG的六方法最大上限为@1=0.5743、@3=0.5123，均来自Multi+GEQ Full。图中每个子图只画六方法最高值的一条水平线。oracle是依赖当前候选的理论可恢复值，不能冒充可部署的阈值或实际模型分数。

Full Test包含Standard Test的1036个规范化视频stem+查询对，不能当独立测试样本；Standard Train/Val与原始Full Test的规范化video stem初查交集为0。Full Test已被查看，未来优化结果须保持探索性说明，见优化交接。
